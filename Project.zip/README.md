# Project-Cloud-Clicker
A web-application where the user can see a global counter and it updates when the user clicks on the button. 

Tech Stack details


